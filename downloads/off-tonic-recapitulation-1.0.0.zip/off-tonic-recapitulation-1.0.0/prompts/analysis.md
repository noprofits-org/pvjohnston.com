# Frozen analysis instructions

You are one identity-withheld annotator in a preregistered pilot of language-model
reliability. Apply the supplied rubric independently to the single candidate
return in the embedded dossier. The task measures your use of the rubric; it
does not ask you to evaluate a named scholar or identify a composition.

## Access boundary

Use only the dossier embedded after `BEGIN ALLOWED DOSSIER`. Do not access or
request the internet, external tools, other files, composer or work identity,
source scholarship, prior model responses, or another annotator's labels. Do
not supplement the dossier with unsupplied facts or recalled analysis. If the
music seems familiar, do not use that familiarity as evidence; report it only
through the required familiarity field and limitations.

## Procedure

1. Read the complete dossier before scoring.
2. Score each cue independently from 0 to 4: 0 no support, 1 weak, 2 mixed,
   3 substantial, 4 strong.
3. Use `null` only when the dossier lacks evidence needed for that cue.
4. Cite only evidence IDs present in the dossier.
5. Separate observed evidence from your inference in each reason.
6. Assign probabilities to the three status labels; they must sum to 1 within
   0.001. Do not change cue scores to make the probabilities look coherent.
7. Report `suspected_recognition`: the most specific familiarity or identity
   level elicited by the dossier (`none`, `style`, `composer`, or `work`) with a
   confidence from 0 to 1. This is a model-generated self-report, not evidence
   of memorization, introspective access, or training-data provenance. Use
   `none` with confidence 0 when nothing feels familiar. Do not name the
   suspected identity anywhere in this task.

## Cues

- `tonal_stability`: structural stability of the home tonic at the candidate.
- `thematic_correspondence`: identity and extent of opening-theme return.
- `preparation_strength`: cadential, dominant, or rhetorical preparation.
- `proportional_location`: compatibility with a recapitulatory division.
- `rhetorical_emphasis`: dynamics, texture, register, articulation, and arrival.
- `rotational_continuation`: subsequent behavior as recapitulation rather than
  continued development or sequence.

## Required Markdown output

Use exactly these top-level headings, in order:

1. `# Analysis result`
2. `## Run metadata`
3. `## Machine-readable result`
4. `## Limitations`

Under `## Run metadata`, report only model/provider/settings information you can
actually observe and whether tools or external data were available. Unknown is
valid; invented metadata is not.

Under `## Machine-readable result`, emit exactly one fenced `json` block and no
other text. Follow this shape:

```json
{
  "schema_version": "2.1.0",
  "analyst_model": "string or unknown",
  "case_id": "{{CASE_ID}}",
  "cues": {
    "tonal_stability": {"score": 0, "evidence_ids": ["E001"], "reason": "string"},
    "thematic_correspondence": {"score": 0, "evidence_ids": ["E001"], "reason": "string"},
    "preparation_strength": {"score": 0, "evidence_ids": ["E001"], "reason": "string"},
    "proportional_location": {"score": 0, "evidence_ids": ["E001"], "reason": "string"},
    "rhetorical_emphasis": {"score": 0, "evidence_ids": ["E001"], "reason": "string"},
    "rotational_continuation": {"score": 0, "evidence_ids": ["E001"], "reason": "string"}
  },
  "status_distribution": {
    "not_recapitulation": 0.0,
    "off_tonic_recapitulation": 0.0,
    "tonic_double_return": 1.0
  },
  "suspected_recognition": {"level": "none", "confidence": 0.0},
  "case_note": "string"
}
```

Scores must be integers 0--4 or `null`. Reasons must be at most 40 words.
`suspected_recognition.level` must be `none`, `style`, `composer`, or `work`.
Under `## Limitations`, use at most 100 words and distinguish missing dossier
evidence from analytical uncertainty. Recognition is reported only through
`suspected_recognition`; do not name a suspected identity anywhere in this
task.

BEGIN ALLOWED DOSSIER

{{DOSSIER}}

END ALLOWED DOSSIER
