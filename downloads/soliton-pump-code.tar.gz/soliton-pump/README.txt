Reproduction code for "How slowly must you pump an anomalous soliton?"
(pvjohnston.com, 2026-07-17)

Model: Tao, Wang & Xu, Nat. Commun. (2026), doi:10.1038/s41467-026-73460-y

Requires numpy only. No scipy, no torch, no GPU.

  python3 soliton_model.py    # validation: k-space vs real-space, Chern numbers, gaps
  python3 wannier.py          # Wannier centres; the flat band at theta=pi
  python3 evolve4.py          # 4th-order Yoshida convergence at fixed T
  python3 lowT.py             # adiabatic threshold scan   -> lowT.json
  python3 plateau.py          # plateau / excursion scan    -> plateau.json

Note: use evolve4 (Yoshida), not evolve (Strang). Strang error grows as T*dt^2,
i.e. it gets worse in exactly the long-period limit the physics lives in.
